
    |---\
    |    \ ____                                 _____
    | |-| |    | ()                     _______ |    |
    | |_| | ---           ___   _      /  ___  \|  __|
    |  _  | |__     ____ |   \ | |    /  /   \  \  |
    | | \ |    ||-|/ __ \| |\ \| |    |  |   |  |  |_
    | |  \| |-- | | /  \ | | \ | |    |  \___/  |    |
    |_|   | |--|| | |--| | |  \  |    \         /  __|
          |____||_|\__   |_|   |_|     \_______/|  |
                    __|  /                      |__|
                    |___/ 

               _____                  _    _
               |    \  _             | |  / |
               |  _  \| |            | | /  /_  ___        ____________
               | | |  | | ___  _  ___| |/  /| |/   \  ____|     |     |
               |  -  /| |/ _ \| |/   |    / |   __  |/ __ \  ___|  ___|
               |  _  \| | / \   | /--|    \ |  /  \ | /__\ \ \  \  \    
               | | |  | | | |   | |  | |\  \| |   | |  ____|\ \  \  \
               |  -   | | \_/   | \__| | \  \ |   | |\ \___  \ \  \  \
               |_____/|_|\___/|_|\___|_|  \_|_|   |_| \____|-|  |_|  |
                                                          |_____|____|
________________________________________________________________________________________________
________________________________________________________________________________________________
                  By:
 
                  B
                   L
                    A
                     C
                      K
                       R
                        A
                         P
                          T
                           O
                            R
                                  !  
________________________________________________________________________________________________
________________________________________________________________________________________________

Copyright (C) 2004 by Blackraptor of OLC
________________________________________________________________________________________________
________________________________________________________________________________________________



                        @@@@@@@@@       @@@@             @@@@@@@ 
                      @@@@@@@@@@@@@     @@@@           @@@@@@@@@@@
                     @@@@@     @@@@@    @@@@          @@@@@@    @@@
                    @@@@@       @@@@@   @@@@         @@@@@ 
                    @@@@@       @@@@@   @@@@         @@@@ 
                    @@@@@       @@@@@   @@@@         @@@@@ 
                     @@@@@     @@@@@    @@@@          @@@@@@    @@@
                      @@@@@@@@@@@@@     @@@@@@@@@@     @@@@@@@@@@@
                        @@@@@@@@@       @@@@@@@@@@       @@@@@@@         

_______________________________________________________________________________________________
_______________________________________________________________________________________________||     @@@@@@@@@
                                                                                               ||   @@@@@@@@@@@@@
                                   Semi-Important Junk!                                        ||  @@@@@     @@@@@
                                                                                               || @@@@@       @@@@@
--=={(| When testing/reviewing the levels, play online. People who review multiplayer levels in|| @@@@@       @@@@@
--=={(| Singleplayer suck. Feel free to distribute these in any non-profit way and be sure to  || @@@@@       @@@@@
--=={(| credit me! Remember to turn on Respawn when hosting or somewhere far away Bobby will be||  @@@@@     @@@@@
--=={(| deeply hurt ;-;. Thanks to all the betatester (most of them will be mentioned somewhere||   @@@@@@@@@@@@@ 
--=={(| further down the text, but I can't remember all of you who played the levels online and||    @@@@@@@@@@@
--=={(| gave suggestions, sorry! So err...drink yer milk and eat your vegetables!              || 
                                                                                               ||
-----------------------------------------------------------------------------------------------||            @@@@
_______________________________________________________________________________________________||            @@@@
_______________________________________________________________________________________________||            @@@@
-----------------------------------------------------------------------------------------------||            @@@@
                                                                                               ||            @@@@
                                                                                               ||            @@@@
                                          CREDITS:                                             ||            @@@@
                                                                                               ||            @@@@@@@@@@
                                         Ze Levelmaker:                                        ||            @@@@@@@@@@
                                           Blackraptor                                         ||
                                                                                               ||           @@@@@@@
                                                                                               ||         @@@@@@@@@@@
                                                                                               ||        @@@@@@    @@@
                                         Ze Tilesets:                                          ||       @@@@@
                                   7th Lava Fall - Dethman                                     ||       @@@@
                                  Ancient Riches - Spazzyman                                   ||       @@@@@ 
                            Diamondus Conversion - NOKA (Epic for the original)                ||        @@@@@@@   @@@                                     Ceramicus Conversion - NOKA (Epic for the original)               ||         @@@@@@@@@@@ 
                                         Neonius - Bluez                                       ||           @@@@@@@
                                           CaKeY - Toxic Bunny                                 ||
                                     Diamondus � - Pyromanus (Partial credit to Epic for beta) ||
                                 Spacey Universe - Disguise                                    ||                                                                        Egypt - Agama                                       ||          !!!!
                          Tubelectric Conversion - Newspaz (Epic for the original)             ||          !!!!
                               Fluff for Thought - Toxic Bunny                                 ||          !!!!               
                                          Swamps - Agama                                       ||          !!!!              
                                     Battleships - CelL (Epic for the Original)                ||          !!!!              
                                                                                               ||          !!!!               
                                           Ze Musics                                           ||                                                                                                                            ||           !!                                         Gateways Part II (GW2.XM) - Nitro/Trauma                              ||          !!!!              
                                        Bonus (s3m) - Jazz Jackrabbit. (Epic)                  ||           !!
                    lemon.announce i (lemonann.mod) - Ripped: JCF Chapman - Converted: Kiwi/Effect)         
                                      Diamondus.s3m - Jazz Jackrabbit. (Epic)                  ||       
                                  White Coffee (XM) - DJZip & Rag00n                           ||
                        Piece of Cake (pieceofc.xm) - $NeiSS"n                                 ||
                                       501trk05.j2b - from AstroniaA's 501 pack.Stup j2b format||          !!!!
                                                      cant tell who made this. Thanks goes out ||          !!!!
                                                      to whoever did!                          ||          !!!!
                      Midnight Desert (mdntdsrt.xm) -  Xerion                                  ||          !!!!
                       UnderWorld || (Unworld-2.j2b) - Alexander Brandon                       ||          !!!!
                                 Binary (Binary.it) - ElectroPiZZa                             ||          !!!!
                         SmallTripToGrinava (st.xm) - pL79                                     ||         
                                   Grace (Grace.xm) - Antisocial                               ||           !!
                     FutureDreams (FutureDreams.xm) - Awesome                                  ||          !!!!                                                                                                              ||           !!
                                                                                               ||
                                          Ze Betatesters                                       ||   
                                           Toxic Bunny                                         ||
                                            Violet CLM                                         ||
                                            FireSworD                                          ||          !!!! 
                                            Labratkid                                          ||          !!!!
                                             Strato                                            ||          !!!!
                                               CelL                                            ||          !!!!
                                           White Rabbit                                        ||          !!!! 
                                             BlurredD                                          ||          !!!!   
                                             Ragnarok                                          ||
                                              Stripe                                           ||
                            Lots of people who joined when I hosted some of these online       ||           !!
                                                                                               ||          !!!!
                 *Most of the betatesters tested a few levels that were included in the pack   ||           !!  
                  (as few as 1), so different people tested different levels.                  ||
                                                                                               ||      2222222222      
-----------------------------------------------------------------------------------------------||      2222222222
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++||            22222
-----------------------------------------------------------------------------------------------||             22222    
                                                                                               ||              22222 
LEVEL HISTORIES                                                                                ||             22222
                                                                                               ||            22222
                                                                                               ||      2222222222222
                           *AzTeC GolD*                                                        ||      2222222222222      
                                                                                               ||
I started this one sometime January 2004. I think most of it was ready sometime early spring/  ||
late winter (February - April). I brushed it up a bit sometime later. One of the earliest      ||
levels in the pack. I remember only showing it to a few people and keeping it as a "Secret     ||       0000000000
unreleased level". I think I only showed it to Strato, maybe FQuist/Trafton, but I'm not sure  ||     00000000000000 
if I did. I tried to make the flow really smooth, but some of the layout got crowded anyways.  ||    00000      00000  
This probably uses all 8 layers, and this was the best music I could find for the level.       ||   00000        00000 
                                                                                               ||   00000        00000
                       *LeMoN NiGhTMaRe v2*                                                    ||   00000        00000
                                                                                               ||    00000      00000
People liked this level a lot I guess, but it was really buggy, so instead of reuploading where||     00000000000000
many people wouldn't even notice, I thought I'd include the fixed version of it instead here.  ||       0000000000
Nothing else to say, but I like the theme and the music of the level.                          ||
                                                                                               ||       0000000000
                         *Diamonds And Guns*                                                   ||     00000000000000
                                                                                               ||    00000      00000
Also started back in January 2004, this was originally going to be a plain and simple Diamondus||   00000        00000
level called "Diamonds of Diamondus" until I renamed it sometime later, inspired by an awesome ||   00000        00000
Transplants song. I hosted this a few times a while ago I believe, and shamelessly included it ||   00000        00000
in the treasure bash. NOKA's diamondus gave me lots of problems. First, I had an old version of||    00000      00000
the set and had to  redownload. Then, because the set had brackets in its name, people kept    ||     00000000000000
crashing when trying to join. It's a basic treasure level. I could've found a better music but ||       0000000000
didn't really want to. Not the highlight of the pack.                                          || 
                                                                                               || 
                            *Quadrants of Light*                                               ||       4444   4444    
Until recently, this was called 4N4. Because of a late level in the lost vikings named that (I ||       4444   4444
think it also had 4 arenas). This started out sort of pathetic, and I exaggerated the progress ||       4444   4444
of it (It was extremely uneyecandied until later on) to try to get it over with. I looked over ||       4444   4444
it, and  decided it needs a lot of fixing, so I did what I could. 4 arenas, each has 35 - 40   ||       4444444444444
 gems about. Was sorta annoying eyecandying this, and I had a lot of good musics for it but in ||       4444444444444
the end whitecoffe.xm ended up winning. Level somehow reminds me of Las Vegas, I want it to    ||       4444444444444 
have a feel like some martian megatropolis, sorta like downtown, where everything at night is  ||              4444
bright and flashy. An alright level.                                                           ||              4444
                                                                                               ||              4444
                           *Land of Waffles and Cake*                                          ||              4444
Started early july/really late june, I was planning it for R3ptile's birthday on July 6th but  ||
didnt make the deadline. I worked pretty fast on this level and it was easy to make. I sorta   ||
rushed the layout a bit, so I dont like it that much. Was finished before Quadrants of Light,  ||----------------------------
too. I really like the music for this, how it fits =D.                                         ||        ( ) ( )
                                                                                               ||       /  \/  \
                           *Crematoria*                                                        ||      /    \   \
It was early december. I was deeply troubled by a lot of irl events which sort of seemed to    ||     /      \   \
beat me down to the ground one after the other, but I still had to finish the pack. The        ||    /        \   \
percentage of its completion was about 57 - 59% or something, and I had less than a month to   ||   /__________\___\
go. I decided to make a ground force level, and decided to use Diamondus B, a recently released||   (___|_|____)_|__)  
set by Pyro. I was planning to make two example levels for it anyways, but Pyro couldnt wait   ||       (_)    (_)
long, so they were dropped. They were originally going to use Garden and Lava. The Garden is an||
SP I will probably never finish, and I wanted to use Lava, and when suggesting gametypes to    ||^ - Two poorly made bells.
Pyro he seemed to like Ground Force, so I decided to try it out. Progress went fast, I finished||----------------------------
this within a week. Thanks to hours of betatesting by FireSworD and Violet, who gave lots of   ||1111222211111122221111111111
brilliant suggestions. Took me a while to find the music for this, although since it was .j2b I||1111222211111122221111111111
had no idea who made it (AstroniaA didnt leave any credits either...). Nice, big, ground force ||1111222211111122221111111111
level. I planned there to be more crates, but too much lag already (poor Violet could barely   ||1111222211111122221111111111
withstand it). I wanted the level to have a feel where youre on a magma planet that gets       ||1111222222222222221111111111
flooded with lava every while, sort of like whatever that jail planet was named in Chronicles  ||1111222222222222221111111111
of riddick. Looked up "fire" in latin because I didnt have a name, and it came up with crematoa||1111222211111122221111111111
or something, so thats what I named it.                                                        ||1111222211111122221111111111
                                                                                               ||1111222211111122221111111111
                            *Inside Your Pillow*                                               ||1111222211111122221111111111
Just for fun I began anothet ground force level. I looked for an underused set, and found this.||1111111111111111111111111111
I wasnt planning to use it (Fluff for thought) but decided to anyways. As an old joke Trafton  ||1111111111111111111111111111
might still remember, I named it Teddy's fluffy land. After a while I thought that sounded     ||1111111111111111111111111111
stupid, so I renamed it. Most of it was finished within 2 hours one late saturday evening (Dec ||1111111111111111111111111111
12 =D). I did what I could with the set. Not my best level, but hey! Use more underused sets   ||1111122222222222222111111111
people! ;(.                                                                                    ||1111122222222222222111111111
                                                                                               ||1111111112222221111111111111
                                                                                               ||1111111112222221111111111111
                               *Blacky's Egypt Race*                                           ||1111111112222221111111111111
I wanted this done for my birthday, and would've had it done too if it was not for my dad who  ||1111111112222221111111111111
needed me to format 500 or so floppies for him (took about 12 hours or so, 4 hours work per    ||1111111112222221111111111111
day). Since I knew I couldnt get this done (loss of inspiration too) it sat there unworked on. ||1111122222222222222111111111
Was originally planned to be a multirouted nicely eyecandied large race level with a bunch of  ||1111122222222222222111111111
joke texts, credits/greetz to people and stuff I'd liked to have for my birthday. Probably my  ||1111111111111111111111111111
first finished level with Egypt. Evily evil set to use, but after 2 years I got the hang of it ||1111111111111111111111111111
(I hope ;P). Lots of hidden "cookies" in this too, and lots of secrets as well.                ||1111111111111111111111111111
                                                                                               ||1111111111111111111111111111
                              *shock Station*                                                  ||----------------------------
When I made this, I forgot NOKA made another (maybe betteR?) tubelectric conversion. Was too   ||----------------------------
late anyways though. Just a strategic subpar level, I included it in the battle bash at # 105  ||  
or  something. Imo, the backround sucks, but I couldnt find anything really fitting for it, and||
didnt want to use the stupid bricks. Definately not the highlight of the pack, but I think I   ||    BBBBBBBBBBBBB
started this February 29th or something....yay leap year.                                      ||    BBBBBBBBBBBBBB    
                                                                                               ||    BBBBBBBBBBBBBBB  
                                 *Zerox Jailbreak*                                             ||    BBBBB    BBBBBBB 
Blur had this contest for a jailbreak (probably died by now), which inspired me to make a      ||    BBBBB    BBBBBBB
jailbreak level. Now, I didnt want to start a new (If I had I'd probably have given up on it)  ||    BBBBBBBBBBBBBBB
so I thought of a good level of mine to edit. LeMoN NiGhTMaRe...where would I place the jails? ||    BBBBBBBBBBBBBB 
I looked at Zerox, and thought it would be a good level (got me an 8.4) so I turned it into a  ||    BBBBBBBBBBBBBB
jailbreak. I wanted that if you'd fall in the lava, you'd get warped to your jail, but that    ||    BBBBBBBBBBBBBBB
 would've been too evil/complicated. Had to host this one a lot to get rid of some major bugs. ||    BBBBB    BBBBBBB
Thanks to Violet and stuff. On a side note, it'll also be ZeRoX's 1 year anniversarry sometime ||    BBBBB    BBBBBBB
near christmas/new year =D. Stuff goes by fast...Thanks to Rag and Blur for trigger fixing.    ||    BBBBBBBBBBBBBBB
                                                                                               ||    BBBBBBBBBBBBBB
                                                                                               ||    BBBBBBBBBBBBB
                                 *Cataclysmic Boulevard*                                       ||
Well, this was one of those levels you start on, then quickly stop working on and abandon, and ||
cant get yourself to start working on this again. I created this level sometime in may maybe,  ||    RRRRRRRRRRRRR 
and havent worked on it intensly since then. In fact, this was only finished December 24th, and||    RRRRRRRRRRRRRR
half of it was made then. This level gave me a migraine. Not only could I not bring myself to  ||    RRRRRRRRRRRRRRR
finish it until I got a good burst of inspiration, but the music. I played through all my 1300+||    RRRRR    RRRRRRR 
musics looking for the right one for this level, and the one I found was 1.75 MB. That meant it||    RRRRR     RRRRRRR
worked well in SP, and gave memory errors in multiplayer. I greately resized the level, and    ||    RRRRR    RRRRRRR
still. I even took out a lot of events (Later they were put back in) such as the spike balls   ||    RRRRRRRRRRRRRRR
and the pulze + dim lights. Still no. BlurredD analyzed this a bit. Even with all the events   ||    RRRRRRRRRRRRRR
removed from the level it still gave memory errors. After a while, Blur told me I'd have to get||    RRRRRR  RRRRRRR
rid of layer 2, 5 and 7 for it to work. Those were essential levels (Especially 5 and 7) so I  ||    RRRRR    RRRRRRR
refused. Just for a note, I even used Mod2J2b and it still gave memory errors. This left me    ||    RRRRR     RRRRRRR
with two choices; pick another music, or edit the current one. I decided to choose the 2nd     ||    RRRRR      RRRRRRR
option. After a while of getting things to work, I just downsampled some of the samples (should||    RRRRR       RRRRRRR  
've done that in the first place) and I got it down to about 1.22 MB, and even less in j2b     ||----------------------------
mode. Finally, it worked. Thanks to Violet for helping me with the obstacles and giving a lot  ||\\\\\\\\\\\\\\\\\\\\\\\\\\\\
of advice to this level, and thanks for BlurredD for helping me fix the music problem. I am so ||////////////////////////////
relieved I got this level over with =P.                                                        ||----------------------------
                                                                                               ||
                         *BONUS*  Two JTTCOC Levels! (+2 Secret Levels)                        ||----------------------------
Eh. The Project died this August (After over a year of work, so I might as well release these. ||////////////////////////////
These were made in 2003 (Not going to put 2003 - 2004 for the pack because these are bonus. You||\\\\\\\\\\\\\\\\\\\\\\\\\\\\
could review these if you want, but they have stupid bugs in them (some of them) and I could   ||----------------------------
make a lot better. Seems like every singleplayer levels I release are old crappy ones. heh     ||                       
                                                                                               ||----------------------------
-----------------------------------------------------------------------------------------------||----------------------------
o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0o0oo0o0o0o0o0o0o0o0oo0o0o0o0o0o0o0o0o0o0o0o0o||/\||   ||/\||    ==
-----------------------------------------------------------------------------------------------||/\||   ||/\||    ==
                                                                                               ||/\||   ||/\||    ==
                                          Gr33tz:                                              ||/\||   ||/\||    ==
                                         FS !                                                  ||/\||   ||/\||    ==
                                        LRK !                                                  ||/\||   ||/\||    ==
                                         TS !                                                  ||/\||   ||/\||    ==
                                        R3P !                                                  ||/\||   ||/\||    ==
                                     VIOLET !                                                  ||/\||   ||/\||    == 
                                        SAL !                                                  ||/\||   ||/\||    ==
                                         AE !                                                  ||/\||   ||/\||    ==
                                       CELL !                                                  ||/\||   ||/\||    ==
                                         TB !                                                  ||/\||   ||/\||    ==
                                     STRATN !                                                  ||/\||   ||/\||    ==
                                        AVK !                                                  ||----------------------------
                                     TRAFTU !                                                  ||----------------------------
                                       BLUR !                                                  || -  
                                     URJAZZ !                                                  ||                    -
                                PPL IN [SI] !                                                  ||           -
                         ANYONE ELSE IN OLC !                                                  ||  -                 -
                                      WISEY !                                                  ||      -
                                     HUGELA !                                                  ||
                                     DARKER !                                                  ||                      -
                                       SPOY !                                                  ||
                                      SKULL !                                                  ||         -
                                         WR !                                                  ||
                                        RAG !                                                  ||              -
                                         GP !                                                  ||
                                     STRIPE !                                                  ||
                          TEH JJ2 COMMUNITY !                                                  || -
         YOU FOR DOWNLOADING & READING THIS !                                                  ||
                                       TUNA !!!                                                ||
-----------------------------------------------------------------------------------------------||
Wow. A year goes by so fast. Hopefully 2005 will hold better experiences and events then 2004 did!)
-----------------------------------------------------------------------------------------------||
                                    SPECIAL THX                                                ||         -
                                       XMPLAY                                                  ||
                                MODARCHIVE.COM (And the trackers there for some awesome quality||
                                                tunes)                                         ||
                                   Modplug & Modplug Tracker                                   || 
                                      NOTEPAD!                                                 ||
                                       EPIC                                                    ||
                                      MICROSOFT!                                               ||
                          SOME OTHER DUDES WHO DESERVE A SPECIAL THX                           ||
-----------------------------------------------------------------------------------------------||
\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\||
-----------------------------------------------------------------------------------------------||
                                                                                               ||
                                                                                               ||
                                                                                               ||
                                                                                               ||
                                           MERRY CHRISTMAS!                                    ||
-----------------------------------------------------------------------------------------------||
(4am right now, yawn)                                                                          ||
-----------------------------------------------------------------------------------------------||
                                                                                               ||
And have a happy new year ;d                                                                   ||
                                                                                               ||
                                                                                               ||
                                                                                               ||
-----------------------------------------------------------------------------------------------||
(Stay Tuned: A semi-new concept level tested by many, been in the works for over a year, a huge|| 
Single Player episode with aroun 30 levels. All coming to YOU within the next year ;D.)        ||
-----------------------------------------------------------------------------------------------||
R473 |-||6|-| p|_z.                                                                            ||
-----------------------------------------------------------------------------------------------||                   
-----------------------------------------------------------------------------------------------||
-----------------------------------------------------------------------------------------------||
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~||                
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~||                      
Also look for: BRH - Episode 1, The Zerox Factory, Lemon Nightmare, Two Race Levels, Some CTF  ||
Level, Cave Clash, and Circuit Plug CTF.                                                       ||
-----------------------------------------------------------------------------------------------||
-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -  ||
 -   -   -   -   -   -   -   -   -   -   -   -   -   -    -   -   -   -   -   -   -   -   -   -||
   -   -   -   -   -   -   -   -   -    -   -   -   -   -   -   -   -   -   -   -   -   -   -  ||           
-----------------------------------------------------------------------------------------------||                        