Welcome to the readme for the level "Jazz 1 Medivo: Team Race". Actually, this .zip file contains four levels, but I'll explain that later.

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

"Team Race" is a version of Race, which really works very simply. I can explain, so I will:

Both teams start out in different rooms, where they turn on their own team's set of triggers. (Blue's ID is 9, Red's is 10) They then fall through the floor into a small starting room, in which they wait until the server (or whoever is operating the controls, doesn't have to be the server) lets them loose. This will usually be when there are as many members on each team as points needed. (Team Race is hosted in CTF) This may or may not include the operator, depending on if he/she decides he/she wants to race as well.

Once everyone is racing (maybe including the operator, maybe not) things start to get fun. Both teams race through the level, (in this case, "A Medivo Race" {Uninspired name, I know}) dodging obstacles and finding the correct path. Icing the other team is allowed, but never kill another player. It messes everything up, and the host may have to reserver.

Once a player (of either team) reaches the finish of the race, he/she is warped to a small layer 3 chamber where he/she falls into a sucker tube. Using a rather simple system of triggers, (that you should be able to easily figure out) he/she is sent into a sucker tube depending on what team he/she is on. If red, he/she first passes a blue base, then a red one, effectively scoring a point for his/her team. Team loyalty is very important. Counterwise, if a blue player goes in, they pass a red base first, then blue. This also will score a point for their team.

As soon as a player has scored a point, he/she is sent into a downward sucker tube, which gives them a bunch of RF ammo and an airboard. It then dispenses them in a long hallway, which is filled with no fire zones. Said player also has the option of taking the sucker tubes at the end of the hall way into a larger flying chamber, which is also filled with no fire zones. Injury is impossible here, which is why those RFs are included. Torture is good for you!

Get it now?

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

Instructions for the host:

First, as soon as you start, (in a little brick room) jump up. You will go through the currently unsolid ceilling, and will be transported to a small room. Stomp the crate on the RIGHT instantly. If you're paranoid, stomp it twice for great measure. Heck, throw in a third stomp! YaY!

This will have two effects. First, the ceilling in the starting rooms (one for each team) will close. Second, the floor will open, making all joiners (both teams) fall through into the place where everyone waits impatiently (and ungratefully) for you to start the race already.

Once there are as many players on each team as points needed, (again, Team Race is hosted in CTF) you hit the crate on the LEFT. Now, you can do one of two things. If you've decided to race along with all the joiners, jump into the newly opened pit on the right. This will transport you into the race area, very near the start. Once inside the race, jump. You will be taken out of your tiny starting box.

On the other hand, if you don't want to race, do not hit the (LEFT) crate until there are as many members on both teams as points needed, NOT including you. Once you hit the left crate when not wanting to race, stay inside your little admin room. Do nothing except make annoying commentary that distracts the racers, making them blow their top and leave in the middle of a race. Of course, that last part is optional.

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

As you should have noticed, if you have any sense of vision, there are four levels in this .zip file. I shall explain:

TeamRace.j2l   .   .   .   .   .   . This is the standard Team Race. Everything above applies to it.
EmptyRoom.j2l  .   .   .   .   .   . This is a 20x15 starting level, which you can host while gathering players for Team Race. This may or not be a good thing, as people have very short attention spans these days. (Mostly) Also, it can be very hard even to get four people in a server. Can you imagine trying to get 16 people on each team, for a total of 32 people?
AMedivoRace.j2l.   .   .   .   .   . For people who couldn't understand the instructions above, this is a modified version of  the basic TeamRace.j2l. It is built just as a normal race level, without the "Team" addons. There is also a little less ice, as it's less useful this way. (In my opinion, anyway)
TwoLapTeamRace.j2l .   .   .   .   . This is another variation of TeamRace.j2l, created when I thought the standard level was a little too short. Here, each player must run through the race area TWICE before they can score a point for their team. Note to players: Try not to be passed by a lap two person while you're in lap one. It's very embarrassing.

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

Also included are >CelL<'s Jazz 1 Medivo conversion, which all these levels use, and song17.s3m. Song17.s3m is the music file for Jazz 1 Medivo, and is also used in EmptyRoom.j2l. Oh right, and this readme file.

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

How does TwoLapTeamRace.j2l work? Semi simple:....:

(Note. I am going to assume you already read the explanation and instructions for TeamRace.j2l during this explanation)

At the start, instead of only getting the team triggers, (Blue's ID is 9, Red's is 10) they also hit an off trigger zone which sets it so they are in lap one. You'll probably understand later, if you don't already.

When joiner dude reaches the finish, he/she is warped to a seperate section of sucker tube parephenalia, (Is that how that is spelled?!?!?) which makes them crash into a block. They fall down into a pit, which has three things happen. One, a text event that displays "Lap 2 of 2". Two, a trigger zone which removes the block they crashed into. (The off trigger zone at the starts is the same ID) Three, it warps them back to the start, where they can start Lap 2. Once they finish Lap 2, the block they hit into before will not be there. They will shoot past it, and enter the system of sucker tubes described in the TeamRace.j2l explanation. Got it? If not, reread what I just said. If still no, try starting from the top of this readme again. Will you do that for me? Pwease?

|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|[>-<]|

Credits Stuffness:

TeamRace.j2l, EmptyRoom.j2l, AMedivoRace.j2l, TwoLapTeamRace.j2l and Team Race concept by Violet CLM.

Help in finding bugs by DizZy DL, and probably someone or someones I'm forgetting. If you are that someone, or one of those someones, please remind me. :P

Thanks go to DizZy DL, Derby, Kaz LJ, iCeD, Agent Megumi, RosetaJOL, Salamander, PhantomWCP, Sprinter, MR MAGOO, GuzzCC, Spaz Boy, Ben, Radium, BlurredD, bugzy and probably some others I'm forgetting. Again, if you're someone I'm forgetting, please remind me. I have a rather imperfect memory.

SPECIAL THANKS goes to Kaz LJ, for doing at least 50% of the work of keeping the testers mentioned above (and probably others) more calm and quiet then they'd normally be. He also understood what was going on when I was totally confused. :D

Also, extra thanks goes to YOU (Yes, YOU! Seated at that monitor. You have untidy hair, don't you?) for downloading this. You'll get even MORE thanks if you review it, and (of course) EVEN MORE if you give it a high review. :P (Ok, so that was corny)