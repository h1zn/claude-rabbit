NONE OF THE TILESET IS MADE BY ME!
However this upload took me a lot of work. I collected all the JJ1 conversions I could find, then I selected the usable versions,eliminated doublets and made an order with the JCS names. I did NOT modified anything besides that name - the tilesets are in their original form with their original filenames.

Why? Because the JCS names of the JJ1 conversions is a huge mess. If someone has a lot of conversions it is extremely hard to find a desired one. Sometimes it is not even possible, since some of them have the same JCS names and JCS treats different tilesets with the same JCS name as one. You can only view 1 version, while not even knowing that the other one is hiding. Apart from that the alphabetization is messed up due to the fact of not having any standard which "prefix" to use. Some use "Jazz1", some, "JJ1:", "J1 - ", "J1", "j1_" etc. I decided to change everything to the shortest possible: J1. That is followed just by a single space (no dots, no macron etc.) and a name of a planet. On the end tere are some symbols to represent the author of the conversion in order to have a clear view - to have different versions alphabetized right next to each other, so you can easily compare them.

I use (V) to indicate that the conversion is done by Violet CLM, (LRK) for Labrat Kid, (IW) for Ice Wolf, (JSZ) for JSZ Jazz, (FoD) for FoD MERC, (S1) for Sonicnathan 1, and (TB) for Toxic Bunny.

You should extract all the tilesets in your JJ2 folder and REPLACE all the files with the same filename that your folder contains. That way you will have a fixed alphabetization of all the JJ1 conversions. And your collection of them wil be more complete (as I doubt people know all of the conversions that I have included).

* THIS WILL NOT AFFECT YOUR LEVELS IN ANY WAY! The levels will still find all the tilesets, as only the filename can affect that, and, as I said earlier, filenames are not changed.

**Also: THIS COLLECTION DOES NOT INCLUDE ANY GARBAGE (some bad conversions that aren't usable in any way).

The collection includes 91 conversions:

Battleships: 2 versions, 1 of them with 4 additional modifications;
Bloxonius: 5 versions, 1 of them with 1 alternative pallette;
Candion: 2 versions;
Carrottus: 1 version;
Ceramicus: 2 versions, 1 of them with alternative pallette;
Crysilis: 2 versions, 1 of them with 2 alternative pallettes;
Deckstar: 1 version;
Deserto: 1 version
Diamondus: 2 versions; 1 of them with 3 alt. pal.
Dreempipes: 1 version;
Exoticus: 3 versions; 1 o them with 1 alt. pal
Fanolint: 4 versions;
Holidaius Day: 1 version
Holidaius Evening: 1 version
Holidaius Night: 1 version
Industrius: 4 versions, 2 of the with 1 alt pal.
Jungrock: 2 versions;
Lagunicus: 1 version
Letni: 1 version
Marbelara: 2 versions;
Medivo: 4 versions;
Megairbase: 2 versions;
Muckamok: 1 version with 1 alt pal.
Nippius: 1 version;
Orbitus: 1 version;
Pezrock: 2 versions;
Raneforus: 3 versions; 1 of them with 3 alt pal.
Scraparap: 2 versions; 1 of them with 1 alt pal;
Sluggion: 2 versions;
Stonar: 3 versions
Technoir: 1 version
Tube Electric: 2 versions;
Turtemple: 1 version with 3 alt pal.
+
5 merges: 2 versions of Mayhem, Exoticus + Candion, Muckamok + Marbelara & Xmas Pack


This collection does NOT include:

1. Remakes of JJ1 tilesets (like for example Noka's Letni or Gus' Exoticus), just the CONVERSIONS.

2. Any of the JJ1 conversions included with the official Jazz Jackrabbit 2 game (the reason being they are extremely bad and I haven't seen them used in a single good level).

3. Some of the extremely bad conversions, which, at the same time, are not used in any reasonable level. For example:
- This conversion of Marbelara: http://www.jazz2online.com/downloads/3853/-/
- The infamous conversion of Nippius made by Catz

4. Lastly, some doublets, or old versions are covered by the newer ones. Here is the list (all the names here are filenames j2t):

j1pezrockOLD is the same as J1Pezrock

JJ1 Bloxonius (LRK) is the same as JJ1 Bloxonius LRK

Jazz 1 Ceramicus is the older version of J1Ceramicus (where all the tiles are the same, the newer version is just extended)

Deserto ( http://www.jazz2online.com/downloads/files/2715/deserto.j2t/info/ ) is Tarquin's original version of Deserto, which later was extended by Violet CLM.

Jazz 1 Exoticus is the same as J1Exoticus

Jazz 1 Jungrock is the same as J1Jungrock

JJ1 Raneforus is JSZ Jazz's old version of Jazz1 Raneforus (which is just extended)




CREDITS: First of all: Violet CLM for teaching me how to change tilesets' JCS names, then all the tileset conversions authors:

Violet CLM: Candion, Crysilis, Deserto, Dreempipes, Exoticus, Holidaius (Day, Evening, Night), Lagunicus, Medivo, Megairbase, Nippius, Orbitus, Pezrock, Raneforus, Scraparap, Scraparap v2, Sluggion, 

Noka: Carrottus, Ceramicus, Diamondus, Industrius, Tubelec, Turtemple

Cell: Battleships, Battleships v2, Ceramicus, Exoticus, Jungrock, Letni, Marbelara, Medivo, Stonar, 

Labrat Kid: Bloxonius, Industrius, Industrius 2005, Jungrock, Stonar

Haze: Mayhem, Muckamok

Astronia: Exoticus + Candion, Muckamok + Marbelara, Xmas Pack

Ice Wolf: Fanolint, Medivo, Megairbase

JSZ Jazz: Bloxonius, Raneforus

FoD Merc: Crysilis, Pezrock

Sonicnathan 1: Deckstar, Fanolint

Minmay: Fanolint, Fanolint v1.2

Tarquin: Marbelara, Raneforus

Newspaz: Technoir, Tubelec

Toxic Bunny: Bloxonius

zapS: Bloxonius

Dethman: Candion

J2LC: Exoticus

Nitro: Bloxonius

Rooster: Industrius